<template>
<header class="site-header">
  <h1 class="logo">Крепёж <span class="highlight">Строй</span></h1>
</header>
</template>

<style scoped>
.site-header {
  background: linear-gradient(to right, #c62828, #fdd835); /* красный → жёлтый */
  padding: 20px 0;
  text-align: center;
  color: white;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  font-family: Arial, sans-serif;
}

.logo {
  margin: 0;
  font-size: 2.5rem;
  font-weight: bold;
}

.highlight {
  color: #fff59d; /* светло-жёлтый акцент */
}

</style>

<script>

</script>